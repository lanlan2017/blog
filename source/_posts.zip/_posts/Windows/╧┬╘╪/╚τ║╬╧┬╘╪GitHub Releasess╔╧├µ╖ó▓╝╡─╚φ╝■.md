---
title: 如何下载GitHub Releasess上面发布的软件
categories: 
  - Windows
  - 下载
abbrlink: 279b049e
date: 2020-06-27 01:23:18
updated: 2022-04-04 00:51:44
---
# 如何下载GitHub Releasess上面发布的软件
## 使用迅雷下载
我尝试了一下,目前可以直接使用迅雷下载.
## Chrome浏览器插件
安装Chrome浏览器插件:[GitHub加速](https://chrome.google.com/webstore/detail/github%E5%8A%A0%E9%80%9F/mfnkflidjnladnkldfonnaicljppahpg/related)

## Chrome浏览器 使用油猴脚本
先安装管理脚本的浏览器插件:[Tampermonkey](https://chrome.google.com/webstore/detail/tampermonkey/dhdgffkkebhmkfjojejmpbldmpobfkfo)

然后安装脚本:
[Github 镜像访问，加速下载](https://greasyfork.org/zh-CN/scripts/398278-github-%E9%95%9C%E5%83%8F%E8%AE%BF%E9%97%AE-%E5%8A%A0%E9%80%9F%E4%B8%8B%E8%BD%BD)
下载打开脚本之前,先退出自己的账号.
## 使用GitHub代下载服务
http://g.widyun.com/
这个网站会转换成一个高速的下载地址
例如
```
https://github.com/Tomotoes/scrcpy-gui/releases/download/1.5.1/ScrcpyGui-1.5.1.win64.exe
```
会转换为:
```
http://g.widyun.com/source/20200623/76ee6b5d12a8de08c39daee3f851d6cf.exe
```
然后再使用多线程下载工具下载即可
## 翻墙
翻墙后就可以下载了.
