---
title: windows软件包管理器Scoop
categories:
  - Windows
  - 下载
abbrlink: 9e62d9d3
date: 2022-05-05 16:23:37
updated: 2022-05-05 16:25:48
---
未完待续
# 参考资料
https://scoop.sh/#/
