---
title: Windows官方软件包管理器winget
categories:
  - Windows
  - 下载
abbrlink: 68c4b9be
date: 2022-05-06 22:17:46
updated: 2022-05-06 22:17:46
---
未完待续
# 参考资料
https://docs.microsoft.com/zh-cn/windows/package-manager/winget/
