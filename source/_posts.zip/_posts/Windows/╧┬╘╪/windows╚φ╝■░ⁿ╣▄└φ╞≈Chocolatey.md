---
title: windows软件包管理器Chocolatey
categories:
  - Windows
  - 下载
abbrlink: da92e58e
date: 2022-05-05 16:08:33
updated: 2022-05-05 16:26:02
---
# 安装Chocolatey

```
Set-ExecutionPolicy Bypass -Scope Process -Force; [System.Net.ServicePointManager]::SecurityProtocol = [System.Net.ServicePointManager]::SecurityProtocol -bor 3072; iex ((New-Object System.Net.WebClient).DownloadString('https://community.chocolatey.org/install.ps1'))
```
未完待续

# 参考资料
https://chocolatey.org/install
https://sspai.com/post/55309
https://juejin.cn/post/6994715287178182693
https://zhuanlan.zhihu.com/p/53421288
https://zhuanlan.zhihu.com/p/42441423
https://www.jianshu.com/p/a1ba81746fe8
