---
title: Excel 换行
categories: 
  - Windows
  - 软件
  - Office
  - Excel
abbrlink: 69c3dc40
date: 2019-11-30 16:30:50
updated: 2022-04-04 00:51:44
---
# Excel 自动换行
在`单元格`上`右键`。选择`设置单元格格式`。然后点点击`对齐`选项卡。勾选上`自动对齐`即可。
# Excel 强制换行
快捷键:`Alt+Enter`
# 参考资料
[https://m.anruan.com/view_75989.html](https://m.anruan.com/view_75989.html)
[https://jingyan.baidu.com/article/7f766dafd5e32d4100e1d06b.html](https://jingyan.baidu.com/article/7f766dafd5e32d4100e1d06b.html)
