---
title: VScode Markdown插件汇总
categories: 
  - Windows
  - 软件
  - VSCode
abbrlink: 913bbb38
date: 2019-12-01 00:35:59
updated: 2022-04-04 00:51:44
---
# VScode Markdown插件汇总

## Markdown Shortcuts
支持的功能
使用方式:
### 鼠标右键方式
选中文字,然后按下鼠标右键,点击对应的方式即可.
### 命令方式
按下ctrl+3然后输入对应的命令即可.
```

```
- [x] 
## Markdown All in One

## Markdown Todo
这个插件可以**勾选todo**或者**取消勾选todo**
使用方式:
按下ctrl+3,打开`命令面板`,然后输入todo,根据提示选择即可进行选择即可
