---
title: editplus快捷键
categories: 
  - Windows
  - 软件
  - VSCode
abbrlink: d0992fb0
date: 2019-02-07 21:47:54
updated: 2022-04-04 00:51:44
---
## editplus移动一行快捷键
`shitf+alt+上下箭头键`可把一行上下移动
## editplus复制一行到快捷键
`ctrl+j`快捷键可以复制一行到到下一行
## 参考资料
[https://zhidao.baidu.com/question/189856473.html](https://zhidao.baidu.com/question/189856473.html)
