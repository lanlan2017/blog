---
title: VSCode 自动换行
categories: 
  - Windows
  - 软件
  - VSCode
abbrlink: 5fce2b9c
date: 2019-12-05 21:23:34
updated: 2022-04-04 00:51:44
---
# VScode设置自动换行
进入`文件`>`首选项`>`设置`，打开设置界面,在搜索框中输入`Editor:Word Wrap`,然后在`常用设置`下找到`Editor:Word Wrap`选项，默认为off,设置为`on`即可.
# 参考资料
[https://www.jianshu.com/p/0b49c7c2e62e](https://www.jianshu.com/p/0b49c7c2e62e)
