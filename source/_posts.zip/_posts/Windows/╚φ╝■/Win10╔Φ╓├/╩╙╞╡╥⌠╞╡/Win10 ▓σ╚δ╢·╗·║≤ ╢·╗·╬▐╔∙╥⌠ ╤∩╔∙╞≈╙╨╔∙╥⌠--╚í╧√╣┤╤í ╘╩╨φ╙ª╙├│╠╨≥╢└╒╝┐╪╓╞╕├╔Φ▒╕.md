---
title: Win10 插入耳机后 耳机无声音 扬声器有声音--取消勾选 允许应用程序独占控制该设备
categories: 
  - Windows
  - 软件
  - Win10设置
  - 视频音频
abbrlink: a6d17185
date: 2020-06-26 00:23:32
updated: 2022-04-04 00:51:44
---
# Win10 插入耳机后 耳机无声音 扬声器有声音
最近Win10更新后,我插入耳机一直没有效果,耳机没有声音,电脑还是使用扬声器播放,就好像没插入耳机一样.
但是我之前使用的时候插入耳机线,耳机是有声音的,这就很奇怪。
经过无数次的尝试后,终于解决了.为此记录一下:

## 打开声音设置
在右下角的声音图标上**右键**,选择**打开声音设置(E)**:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/NoSoundFromWiredHeadphones/1.png)
## 声音控制面板
点击**声音控制面板**,选择**扬声器**,点击**属性(P)**按钮
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/NoSoundFromWiredHeadphones/2.png)
##  取消勾选 允许应用程序独占控制该设备
点击**高级**选项卡,在**独占模式**哪里**取消勾选** **允许应用程序独占控制该设备**
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/NoSoundFromWiredHeadphones/3.png)

当然如果**取消勾选 允许应用程序独占控制该设备**之后,还是没有解决问题,那可能是其他原因.
<!-- 
Blog/Windows/Software/Win10Settings/NoSoundFromWiredHeadphones/1
Blog/Windows/Software/Win10Settings/NoSoundFromWiredHeadphones/1
Blog/Windows/Software/Win10Settings/NoSoundFromWiredHeadphones/1 
-->
# 参考资料

win10插上耳机电脑还是有声音，怎么处理？ - 不明真相的吃瓜群众的回答 - 知乎
https://www.zhihu.com/question/48204899/answer/656280146
