---
title: Win10 Conexant SmartAudio HD声卡 插入耳机没反应
categories: 
  - Windows
  - 软件
  - Win10设置
  - 视频音频
abbrlink: 274cd760
date: 2020-07-06 04:24:48
updated: 2022-04-04 00:51:44
---
# Win10 Conexant SmartAudio HD声卡 插入耳机没反应
## 打开SmartAudio
按下快捷键`Win+X`,然后按下快捷`S`,打开小娜的**搜索框**,输入控制面板,进入**控制面板**,点击**硬件和声音**,点击**SmartAudio**:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/1.png)
## SmartAudio设置
### 音频导向器设置
点击**音频导向器**(下方倒数第二个),选择**MULTI-STREAM**:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/2.png)
### 插口配置
点击**插口配置**(下方最后),选中**头戴式耳麦**,勾选上**关闭插口配置弹出窗囗**:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/3.png)
### 音量混合器
点击**音量混合器**,然后**插入耳机**,如果带有耳机图标的音量控件亮起来了,那就识别成功了:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/4.png)
这样就可以了,关掉SmartAudio窗口
## 后续使用
SmartAudio设置好之后,可以在任务栏右下角的**声音图标**上面**点击鼠标左键**,选择**使用耳机播放**或者**使用扬声器播放**:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/5.png)

<!--
Blog/Windows/software/Win10Settings/VideoAndAudio/Win10ConexantSmartAudioHDSoundCard/NothingHappensWhenIPlugInMyHeadphones/
-->
