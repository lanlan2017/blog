---
title: Xshell通过用户名和密码连接远程Linux服务器
categories: 
  - Windows
  - 软件
  - Win10设置
  - 远程控制
abbrlink: fd12fec7
date: 2021-07-08 00:57:26
updated: 2022-04-04 00:51:44
---
# Xshell通过用户名和密码连接远程Linux服务器
具体操作步骤如下图所示：
## 文件 新建
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword/1.png)
## 连接
主要是设置名称和主机：协议的话一般都是SSH，端口号一般也是22。
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword/2.png)

## 用户身份验证
方法，这里选择Password，然后在上面的输入框中分别输入用户名和密码。最后点击确定即可：
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword/3.png)
## 接受并保存主机秘密
第一次连接的时候会弹出如下警告窗口，点击接受并保存按钮即可。
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword/4.png)
## 连接成功效果
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/Win10_Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword/5.png)

<!-- Blog/Windows/Software/Win10Settings/RemoteControl/XShellIsConnectedToTheLinuxServerViaUsernameAndPassword -->
