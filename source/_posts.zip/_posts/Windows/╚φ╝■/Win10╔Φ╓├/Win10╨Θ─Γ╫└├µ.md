---
title: Win10虚拟桌面
categories:
  - Windows
  - 软件
  - Win10设置
abbrlink: cddbb804
date: 2023-03-23 14:12:44
updated: 2023-03-23 14:12:44
---

# Win10虚拟桌面

## 如何创建 虚拟桌面
按Win+Tab键，打开任务视图，点击右上方的新建桌面，就可以创建一个新的虚拟桌面了。


## 快捷键

按**Win+Ctrl+左箭头**，可以切换到左边的桌面。
按**Win+Ctrl+右箭头**，可以切换到右边的桌面。

## 参考资料
https://zhuanlan.zhihu.com/p/26744146
