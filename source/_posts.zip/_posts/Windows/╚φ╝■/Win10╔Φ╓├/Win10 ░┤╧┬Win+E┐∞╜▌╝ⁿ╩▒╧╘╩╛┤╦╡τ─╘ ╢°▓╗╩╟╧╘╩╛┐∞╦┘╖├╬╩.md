---
title: Win10 按下Win+E快捷键时显示此电脑 而不是显示快速访问
categories: 
  - Windows
  - 软件
  - Win10设置
abbrlink: 6f73218
date: 2019-11-24 11:33:50
updated: 2022-04-04 00:51:44
---
# 问题描述
Win10 中按下`Win+E`快捷快捷键,可以快速打开**Windows资源管理器**,但是默认打开的时`快速访问`,但是我经常要进入的**盘符**,频繁的手动操作让我烦躁.
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/win10/setting/explorer/openthisComputer/1.png)

# 设置Windows资源管理器 启动时显示此电脑
点击Windows资源管理上方的**文件**菜单,然后点击**更改文件夹和搜索选项(Q)**。
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/win10/setting/explorer/openthisComputer/2.png)

然后再`常规`选项卡，再`打开文件资源笞理器时打开:`选择框中,选择`此电脑`即可:
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/win10/setting/explorer/openthisComputer/3.png)
