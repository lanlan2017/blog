---
title: 打开win10启动项文件夹
categories: 
  - Windows
  - 软件
  - Win10设置
abbrlink: 62f05e9a
date: 2021-07-16 09:12:19
updated: 2022-04-04 00:51:44
---
# 查找路径打开
```
C:\Users\用户名\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup
```
把上面的用户名换成你的用户名即可打开。
# 通过运行打开
按下win+r快捷键，然后输入如下命令，即可打开win10的启动项文件夹
```cmd
shell:startup
```
