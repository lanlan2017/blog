---
title: win10优化驱动器
categories:
  - Windows
  - 软件
  - Win10设置
abbrlink: c9879bfe
date: 2022-04-16 14:15:43
updated: 2022-04-16 14:15:43
---
# win10优化驱动器
## 进入优化驱动器
按Win+I键打开win10设置，然后在搜索框中搜索 存储 ，进入存储设置，然后点击下方的优化驱动器。
![image-20220416141648001](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220416141648.png)

## 选择驱动器进行优化
<!-- more -->
在弹出的界面中选择驱动器，然后点击下方的按钮进行优化。

![image-20220416141723386](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220416141723.png)