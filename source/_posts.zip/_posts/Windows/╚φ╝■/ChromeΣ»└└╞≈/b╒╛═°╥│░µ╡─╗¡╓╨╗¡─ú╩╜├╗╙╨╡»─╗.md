---
title: b站网页版的画中画模式没有弹幕
categories: 
  - Windows
  - 软件
  - Chrome浏览器
abbrlink: 7f36a8b9
date: 2020-08-05 03:04:10
updated: 2022-04-04 00:51:44
---
# b站网页版的画中画模式没有弹幕
到今天为止,画中画模式确实没有弹幕.
# 一边看视频一边看评论
如果想要一遍看视频,一边看评论.则可以打开mini模式.
![](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/Windows/Software/ChromeBrowser/Picture-in-pictureFunctionWithoutBarrage/1.png)

# 一边看视频一边做其他事情
网页全屏,然后使用分栏模式.浏览器占半个屏幕,其他软件占半个屏幕

## 使用插件
悬浮画中画播放器:
https://chrome.google.com/webstore/detail/%E6%82%AC%E6%B5%AE%E7%94%BB%E4%B8%AD%E7%94%BB%E6%92%AD%E6%94%BE%E5%99%A8/gdcfkpenohoihodlddbcgpdjhmdjepnb
B站的画中画功能,只是在当前网页中显示,无法一直显示在最顶层.
<!-- 
Blog/Windows/Software/ChromeBrowser/Picture-in-pictureFunctionWithoutBarrage/1
-->
