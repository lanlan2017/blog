---
title: 批处理if命令
categories:
  - Windows
  - CMD
  - 批处理
  - 构建程序相关命令
abbrlink: 29b9de5e
date: 2022-04-24 21:30:03
updated: 2022-04-24 21:30:03
---
# 批处理if命令
```bat
if (condition) (do_something) ELSE (do_something_else)
```
<!-- more -->

未完待续
## 参考资料
https://www.yiibai.com/batch_script/batch_script_if_statement.html
https://www.yiibai.com/batch_script/batch_script_nested_if_statements.html
https://www.yiibai.com/batch_script/batch_script_if_else_statement.html
https://www.w3cschool.cn/pclrmsc/gmjsnz.html