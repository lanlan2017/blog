---
title: 如何使用bat关闭其他指定的bat程序
categories:
  - Windows
  - CMD
  - 批处理
  - 系统相关命令
abbrlink: 5d4f46f1
date: 2022-05-04 11:36:46
updated: 2022-05-04 11:36:46
---
未完待续
# 参考资料
https://jingyan.baidu.com/article/a501d80c150ebdec630f5e1f.html
