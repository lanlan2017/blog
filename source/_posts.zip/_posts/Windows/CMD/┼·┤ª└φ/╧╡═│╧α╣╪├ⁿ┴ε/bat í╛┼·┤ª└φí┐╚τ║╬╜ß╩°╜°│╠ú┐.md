---
title: bat 【批处理】如何结束进程？
categories:
  - Windows
  - CMD
  - 批处理
  - 系统相关命令
abbrlink: 6aeb7cf8
date: 2022-05-04 11:33:36
updated: 2022-05-04 11:33:36
---
未完待续
# 参考资料
https://blog.csdn.net/qq_34924407/article/details/82047876
