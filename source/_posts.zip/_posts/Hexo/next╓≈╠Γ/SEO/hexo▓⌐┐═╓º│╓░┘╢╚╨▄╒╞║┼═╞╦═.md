---
title: hexo博客支持百度熊掌号推送
categories: 
  - Hexo
  - next主题
  - SEO
abbrlink: 5f9ceba2
date: 2018-10-30 11:11:24
updated: 2022-04-04 15:56:38
---
先写到这里，后续审核通过了我在再增加,注册这个只是为了，让我的博客站点在百度搜索中的排名靠前点。SEO还真心不容易啊。
## Hexo安装插件支持百度熊掌号自动推送 ##
具体参照我的这篇文章：[ERROR Deployer not found：baidu_xz_url_submitter](https://www.lansheng.net.cn/blog/2740f49f/)
我不想再重复写一次了。
