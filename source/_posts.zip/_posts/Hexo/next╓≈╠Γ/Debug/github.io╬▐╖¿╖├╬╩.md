---
title: github.io无法访问
categories: 
  - Hexo
  - next主题
  - Debug
abbrlink: ffecb566
date: 2021-03-17 02:37:25
updated: 2022-04-04 15:56:38
---
# 解析地址
```
140.82.112.4 github.com
199.232.69.194 github.global.ssl.fastly.net
185.199.108.153 assets-cdn.github.com
185.199.108.133 user-images.githubusercontent.com
```
