---
title: eclipse HTML代码格式化
categories: 
  - Java
  - Java EE
  - IDE
  - eclipse
abbrlink: 503e570d
date: 2019-05-29 16:12:41
updated: 2022-04-04 00:51:44
---
# eclipse HTML代码格式化 #
如下图所示:
![这里有一张图片](https://image-1257720033.cos.ap-shanghai.myqcloud.com/blog/JavaEE/IDE/Eclipse/Format/HTML/1.png)
- `Line width`:表示代码显示的宽度
- `Split multiple attributes each on a new line`:表示`html`标签的属性各自放在一行,这个没必要.
- `Align final bracket in multi-line element tags`:表示对齐多行元素的结束符
- `Clear all blank lines`:删除空行
- `Indent using spaces`:使用空格对齐,而不是`tab`键
