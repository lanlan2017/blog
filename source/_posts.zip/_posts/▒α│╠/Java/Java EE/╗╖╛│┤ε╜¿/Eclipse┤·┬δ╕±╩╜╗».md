---
title: Eclipse代码格式化
categories: 
  - Java
  - Java EE
  - 环境搭建
abbrlink: 4d0864a5
date: 2019-04-27 22:28:28
updated: 2022-04-04 00:51:44
---
## 注解格式化 ##
第一个按钮选择最后一个,
```
Wrap all elements, except first element if not necessary
```
第二个选项选中,有阴影表示选中.
第三个选项选第二个:
```
Indent by one
```
这个缩进小一点.如下图所示:
![这里有一张图片](https://image-1257720033.cos.ap-shanghai.myqcloud.com/blog/JavaEE/IDE/Eclipse/Format/1.png)
格式化效果如下图所示:
![这里有一张图片](https://image-1257720033.cos.ap-shanghai.myqcloud.com/blog/JavaEE/IDE/Eclipse/Format/2.png)
