---
title: Git 克隆指定分支
categories: 
  - Git
  - 命令
abbrlink: 7aaab990
date: 2019-12-01 15:37:28
updated: 2022-04-04 00:51:45
---
# 命令格式
```shell
git clone -b 分支名 git仓库地址 本地路径
```
例如:
```shell
git clone -b src git@github.com:lanlan2017/lanlan2017.github.io.git blogRoot
```
