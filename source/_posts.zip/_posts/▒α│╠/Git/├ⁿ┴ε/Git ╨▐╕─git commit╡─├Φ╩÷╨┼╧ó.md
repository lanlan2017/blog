---
title: Git 修改git commit的描述信息
categories: 
  - Git
  - 命令
abbrlink: 4e1204e0
date: 2019-12-08 22:49:12
updated: 2022-04-04 00:51:45
---
# commit后还没有push
输入如下命令:
```shell
git commit --amend
```
然后会在vim中打开一个文件,在vim里面修改这个文件即可:

# 参考资料
[https://blog.csdn.net/lang523493505/article/details/80828279](https://blog.csdn.net/lang523493505/article/details/80828279)
[https://blog.csdn.net/yulsh/article/details/54613189](https://blog.csdn.net/yulsh/article/details/54613189)
