---
title: UTF-8编码终端下Git diff GBK编码文件乱码解决
categories:
  - 编程
  - Git
  - GitBash
abbrlink: 2f0fee28
date: 2022-05-04 11:28:06
updated: 2022-05-04 11:28:06
---
# 参考资料
https://www.cnblogs.com/Mr-Koala/p/14636585.html