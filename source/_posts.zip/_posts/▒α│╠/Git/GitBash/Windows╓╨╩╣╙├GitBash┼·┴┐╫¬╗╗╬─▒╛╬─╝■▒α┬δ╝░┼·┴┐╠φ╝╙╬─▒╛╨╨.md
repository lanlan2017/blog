---
title: Windows中使用GitBash批量转换文本文件编码及批量添加文本行
categories:
  - 编程
  - Git
  - GitBash
abbrlink: 841265af
date: 2022-05-04 00:12:44
updated: 2022-05-04 00:12:44
---
# 参考资料
https://blog.csdn.net/mostone/article/details/19084123