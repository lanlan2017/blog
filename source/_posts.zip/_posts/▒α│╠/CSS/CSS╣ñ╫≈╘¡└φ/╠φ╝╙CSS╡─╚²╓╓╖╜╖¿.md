---
title: 添加CSS的三种方法
categories: 
  - CSS
  - CSS工作原理
abbrlink: 9d1ffcf6
date: 2019-05-11 11:31:24
updated: 2022-04-04 00:51:44
---
# 添加CSS的三种方法
<iframe frameborder= "no" border= "0" marginwidth= "0" marginheight= "0" width=800 height=600 src= "http://edrawcloudpubliccn.oss-cn-shenzhen.aliyuncs.com/viewer/self/738327/share/2019-5-11/1557545471/main.svg"></iframe>

# CSS规则
<iframe frameborder= "no" border= "0" marginwidth= "0" marginheight= "0" width=1000 height=3000 src= "http://edrawcloudpubliccn.oss-cn-shenzhen.aliyuncs.com/viewer/self/738327/share/2019-5-11/1557546791/main.svg"></iframe>
