---
title: js执行批处理文件 js执行dos命令
categories:
  - 编程
  - JavaScript
  - 系统调用
abbrlink: 7c2b29e6
date: 2022-05-04 11:40:32
updated: 2022-05-04 11:40:32
---
未完待续
# 参考资料
https://blog.csdn.net/wodexiaoyang/article/details/49583315