---
title: VScode比较两个文件的差别
categories: 
  - IDE
  - VSCode
abbrlink: 7efc26e
date: 2020-06-23 01:00:32
updated: 2022-04-04 00:51:45
---
# VSCode比较两个文件的差别
## 打开资源管理器
按下shift+ctrl+E快捷键打开资源管理器
## 右键 选择以进行比较
在**一个文件**上**右键**,选择:**选择以进行比较**这个选项。
## 右键 与已选项目进行比较
在**另一个文件**上**右键**,选择**与已选项目进行比较**这个选项。
# 参考资料
[https://www.cnblogs.com/dead-micky/p/8472647.html](https://www.cnblogs.com/dead-micky/p/8472647.html)
