---
title: 使用Graphviz绘制dot图像
categories:
  - 编程
  - IDE
  - VSCode
abbrlink: d8e0f438
date: 2021-07-26 23:34:27
updated: 2021-07-26 23:34:27
---
# 下载 安装Graphviz
下载地址:
http://www.graphviz.org/download/

# 安装Graphviz的vscode插件：

搜索Graphviz,然后安装你喜欢的插件即可，


```graphviz
graph demo {
    "Browser" -- {"Chrome", "Fiefox", "Safari", "..."}
}
```