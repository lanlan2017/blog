---
title: VSCode 中文翻译并替换为英文插件 翻译替换插件
categories: 
  - IDE
  - VSCode
abbrlink: f539cba6
date: 2020-02-12 01:53:57
updated: 2022-04-04 00:51:45
---
# 插件地址
[https://marketplace.visualstudio.com/items?itemName=hancel.google-translate](https://marketplace.visualstudio.com/items?itemName=hancel.google-translate)
# 安装
打开上面的超链接,然后点击:**Install**按钮,然后点击弹出上的**打开 Visual Studio code**按钮,然后点击安装即可.
# 如何使用翻译替换功能
1. 选中要翻译的词语,中文或者中英混合都可以
2. 然后按下ctrl+3快捷键打开命令搜索框,输入translate and Replace命令,
3. 然后选择translate and Replace这个命令,
4. 然后回车即可
