---
title: eclipse log4j自动补全插件
categories: 
  - IDE
  - eclipse
abbrlink: 335e8fcf
date: 2021-08-18 10:41:50
updated: 2022-04-04 00:51:45
---
# 查找eclipse的log4j插件
进入eclipse插件官网：[https://marketplace.eclipse.org/](https://marketplace.eclipse.org/)
输入log4j进行查找：

# 这个插件只能在java类中自动补全
不会给log4j.xml自动补全。
