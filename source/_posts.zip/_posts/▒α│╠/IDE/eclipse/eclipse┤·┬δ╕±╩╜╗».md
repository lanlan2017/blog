---
title: eclipse代码格式化
categories: 
  - IDE
  - eclipse
abbrlink: 1bed7c21
date: 2021-07-13 10:32:39
updated: 2022-04-04 00:51:45
---
# Preference中搜索Formatter
Preference然后搜索Fromatter，进入Formatter，然后edit。
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/programming/Idea/Eclipse/EclipseCodeFormattingSettings/1.png)

# 然后搜索Comments
![图片](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/programming/Idea/Eclipse/EclipseCodeFormattingSettings/2.png)

<!-- Blog/programming/Idea/Eclipse/EclipseCodeFormattingSettings -->
