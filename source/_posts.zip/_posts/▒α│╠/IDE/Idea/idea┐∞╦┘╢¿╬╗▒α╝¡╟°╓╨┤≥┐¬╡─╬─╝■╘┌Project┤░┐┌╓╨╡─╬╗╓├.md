---
title: idea快速定位编辑区中打开的文件在Project窗口中的位置
categories: 
  - 编程
  - IDE
  - Idea
date: 2023-11-20 17:51:22
updated: 2023-11-20 17:52:13
---
# 点击Project窗体上的齿轮图标
在编辑区中点击，你要定位的文件。然后打开project窗口，然后点击从左到右的第一个按钮，这个按钮的图标是一个类似汽车轮子的图标。如下图所示：

![这里有一张图片](https://img-blog.csdnimg.cn/20190402150740516.png?x-oss-process=image/watermark,type_ZmFuZ3poZW5naGVpdGk,shadow_10,text_aHR0cHM6Ly9ibG9nLmNzZG4ubmV0L2JlZ3VpbGU=,size_16,color_FFFFFF,t_70)

![Select Opened File](https://img-blog.csdnimg.cn/20190402150740516.png)

# 参考资料
https://blog.csdn.net/beguile/article/details/88972586