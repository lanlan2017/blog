---
title: termux 安装软件
categories: 
  - Linux
  - Termux
abbrlink: d305bdc
date: 2019-11-01 10:14:33
updated: 2022-04-04 00:51:45
---
# 更新软件
```shell
apt update
```
# 查看已安装软件
```shell
apt list
```
