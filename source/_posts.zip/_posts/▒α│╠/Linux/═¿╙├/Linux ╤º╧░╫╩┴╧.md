---
title: Linux 学习资料
categories: 
  - Linux
  - 通用
abbrlink: 71914ed4
date: 2021-04-03 21:14:06
updated: 2022-04-04 00:51:45
---
# 学习网站

|网站名称|URL|
|:---|:---|
|蓝桥云课|[https://www.lanqiao.cn/](https://www.lanqiao.cn/)|
|鸟哥的Linux 私房菜|[http://linux.vbird.org/](http://linux.vbird.org/)|

# 技术手册

|网站名称|URL|
|:---|:---|
|Linux Command|[https://wangchujiang.com/linux-command/](https://wangchujiang.com/linux-command/)|
|Linux Command github|[https://github.com/jaywcjlove/linux-command](https://github.com/jaywcjlove/linux-command)|
|Linux命令大全(手册)|[https://www.linuxcool.com/](https://www.linuxcool.com/)|
|语言中文网|http://c.biancheng.net/linux_tutorial/|

# Linux资讯

|网站名称|URL|
|:---|:---|
|Linux公社|[http://www.linuxidc.com/](http://www.linuxidc.com/)|
https://www.linuxde.net/
