---
title: Linux 常见命令2
categories: 
  - Linux
  - 通用
abbrlink: 196cfe9b
date: 2019-11-01 10:14:33
updated: 2022-04-04 00:51:45
---
# tree
## 安装
```shell
pkg install tree
```
# pstree
# rsync
