---
title: wps免费会员
categories:
  - 其他
  - 薅羊毛
abbrlink: b7a3e430
date: 2022-04-19 15:43:47
updated: 2022-04-19 15:43:47
---
# 在WPS会员 微信公众号可以签到领会员
在WPS会员微信公众号中点击下方的 **福利&签到** 按钮，然后点击 **打卡免费领会员** 进入会员领取界面，按提示操作即可。

<img src="https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220419154205.png" alt="image-20220419154204870" width="50%">

需要注意的是，还需要在次日06:00~13:00时再次打卡才算是完成一次任务，才能得到会员。
<!-- more -->

<!-- ![image-20220419154248077](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220419154248.png) -->

<img src="https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220419154248.png" alt="image-20220419154248077" width="50%">
