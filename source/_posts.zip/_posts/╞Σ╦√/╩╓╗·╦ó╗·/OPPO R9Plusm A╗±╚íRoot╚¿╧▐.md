---
title: OPPO R9Plusm A获取Root权限
categories: 
  - 其他
  - 手机刷机
abbrlink: 95547b91
date: 2021-03-07 11:51:19
updated: 2022-04-04 16:02:45
---
# 回退到旧的系统版本

## 下载旧版本的系统ROM包
进入官网[ColorOS官网](https://www.coloros.com/rom),然后点击右上方的[下载](https://www.coloros.com/rom)菜单。
然后选择手机对应的系列，R系列，然后找到手机对应的型号，[OPPO R9Plus（全网通）](https://www.coloros.com/rom/firmware?id=121)
最后在**历史版本**中选择一个低版本的的,如：
[版本号：正式版-160405](https://fsopen.coloros.com/3/oppowww/androidrom/r9plus/R9PlusmA_11_A.10_OTA_010_all_201604051824.zip),然后点击右侧的立即下载，即可下载该ROM.

## 将ROM复制到手机内部存储根目录
## 回退系统版本
关机
```
先按住两个音量键，然后再按电源键
按开机键+音量减键
按下开机键，然后同时按音量上键和音量下 键
```

进入Recovery,选择简体中文
找到刚才的ROM的zip包，更新系统

# 安装KingRoot
下载KingRoot(KingRoot_v4.85),使用KingRoot获取Root权限。
第一次Root可能不成功，多试几次， 我试了两次后成功了。

# 安装谷歌框架
## 下载360手机助手
## 下载VPN
## 下载GG谷歌安装器
- 打开GG谷歌安装器，进行修复，修复不一定会成功，但是会把谷歌框架需要的apk下载到内部存储的**根目录**下
- 安装内部存储根目录下的谷歌框架，四件套必须得按照一定的顺序依次安装，顺序为
  - Google框架服务(GoogleServicesFramework.apk)
  - Google帐号管理程序(GoogleLoginService.apk)
  - Google Play服务(GooglePlayService.apk)
  - Google Play商店(GooglePlay.apk)
- 打开VPN,连接到外网
- 打开Google Play store,按照提示登录谷歌账号
- 下载Google Play store上的相关软件。

