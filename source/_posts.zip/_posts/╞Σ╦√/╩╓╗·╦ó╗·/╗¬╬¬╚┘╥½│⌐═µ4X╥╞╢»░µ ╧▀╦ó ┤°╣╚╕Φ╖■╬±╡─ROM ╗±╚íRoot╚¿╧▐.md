---
title: 华为荣耀畅玩4X移动版 线刷 带谷歌服务的ROM 获取Root权限
categories: 
  - 其他
  - 手机刷机
abbrlink: a0a42cc6
date: 2020-09-24 01:57:49
updated: 2022-04-04 15:13:22
---
# 华为荣耀畅玩4X移动版 线刷 带谷歌服务的ROM 获取Root权限
## 手机基本信息
- 华为荣耀畅玩4X移动版 标准版
- 1G运行内存
- Che2-TL00型号

## 解锁
到淘宝上找商家解锁,十块钱左右.

## 下载带谷歌服务的ROM
- [刷机天堂 荣耀4X官方线刷ROM](http://shuajitt.com/firmwarelist/huawei-rongyao4x/)
- [华为荣耀4X移动标配Che2-TL00 官方线刷固件C00B39 刷机包下载](http://shuajitt.com/firmwarelist/huawei-rongyao4x/1110.html)
- 链接：https://pan.baidu.com/s/1DtAiHSlbxLVu4tYy1XVqgA   提取码：szv9 

## 线刷ROM
### 下载奇兔刷机
进入奇兔刷机官网[http://www.7to.cn/](http://www.7to.cn/),下载软件,然后安装软件.
### 手机开启USB调试
进入**设置**,**关于手机**,在**版本号**上连续点击7次,即可打开开发者模式。
然后返回,进入**开发人员选项**,然后打开**USB调试**的按钮即可.
### 使用线刷大师
打开奇兔刷机,用数据线连上手机,然后点击**线刷大师**,点击**选择固件**按钮,选择下载好的ROM的.zip包,然后点击**开始刷机**按钮即可.

## 给手机刷入 第三方recovery
### 下载第三方recovery cofface Recovery
[https://club.huawei.com/thread-3533408-1-1.html](https://club.huawei.com/thread-3533408-1-1.html)
cofface Recovery下载地址：
链接:http://pan.baidu.com/s/1ntMIt53密码: vfu3
链接：https://pan.baidu.com/s/1apNFeQOkYOCjQP_zVXoIpw 提取码：nxwq

## 刷入root.zip 获取ROOT权限

### 下载Root包
#### Root包说明
[Root包说明](https://www.huaweirom.com/bibei/2686.html)
华为手机安卓4.3 4.4取权限的ROOT单刷包，适合华为手机大部分无法使用一键ROOT的手机。
只要您的手机有第三方recovery，不管系统是5.0还是4.4,都可以卡刷本ROOT单刷包取得超级权限。

#### root包下载地址
[Root包下载地址](https://www.huaweirom.com/hua/download.html?open=0&aid=2686&cid=3)
链接：https://pan.baidu.com/s/1ghleK_9rZCDFlzhJX9_yeg  提取码：qyua

### 重命名root包
将ROOT_For_EMUI3.0.zip,重命名为root.zip
### 复制root.zip到内部存储根目录
将root.zip复制到SD卡,然后使用手机的文件管理器,将这个root.zip复制到**内部存储**的根目录.
### 使用cofface Recovery开启Root权限

## 安装谷歌应用
安装翻墙软件,推荐使用老王VPN
我这款ROM已经自带谷歌的GMS服务了,只要下载一个Google Play store,即可下载安装Google play上的软件。
