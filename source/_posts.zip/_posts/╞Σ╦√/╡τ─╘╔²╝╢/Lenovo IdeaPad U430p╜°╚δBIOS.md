---
title: Lenovo IdeaPad U430p进入BIOS
categories:
  - 其他
  - 电脑升级
abbrlink: 46fa5aca
date: 2022-07-01 16:23:37
updated: 2022-07-01 16:23:37
---
# Lenovo IdeaPad U430p进入BIOS
- 关机状态下,按一键恢复键(电脑左侧,电源键正下方的小按键)
- 开机时不停的按F2,或Fn+F2

<!-- more -->

1、首先尝试开机后不停按F2或Fn+F2，如果没有反应，则在关机状态下按下电脑左边的一键恢复键，有一个箭头标志的按键；

![u430p笔记本进入BIOS步骤1](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220701162705.png)

2、这时候会启动进入这个Novo菜单，按↓方向键选择BIOS Setup，按回车键；

![u430p笔记本进入BIOS步骤2](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220701162758.png)

3、这样就进入到BIOS界面，如图所示。

![u430p笔记本进入BIOS步骤3](https://raw.githubusercontent.com/lanlan2017/images/master/Blog/2022/04/20220701162830.png)

# 参考资料
https://www.xitongcheng.com/jiaocheng/xtazjc_article_30473.html