---
title: 给电脑2安装python和pyautogui
categories:
  - 其他
  - 电脑升级
abbrlink: 53d18241
date: 2022-07-01 20:08:20
updated: 2022-07-01 20:08:20
---


# 需要import
import pyautogui
import time
```
pip install pyautogui==0.9.50
pip install opencv-python -i https://pypi.tuna.tsinghua.edu.cn/simple
pip install pillow
```
