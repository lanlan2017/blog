---
title: LaTex加粗下划线
categories: 
  - 其他
  - latex
  - LaTex语法
abbrlink: 55e94bf9
date: 2019-12-07 12:51:38
updated: 2022-04-04 15:13:22
mathjax: true
---
# latex加粗
```
\textbf{LaTeX}
```

例如:$\textbf{LaTeX}$
# latex下划线
```
\underline{}
```

例如:$\underline{x+y=z}$

# 参考资料
[https://jingyan.baidu.com/article/48206aeadf374c216bd6b36e.html](https://jingyan.baidu.com/article/48206aeadf374c216bd6b36e.html)
