---
title: 百度文字识别 Java Demo
categories:
  - 其他
  - 我的软件
  - 百度文字识别
abbrlink: ad54e622
date: 2020-09-05 06:06:31
updated: 2020-09-05 06:06:31
---
# 使用步骤
## 控制台中创建文字识别应用
## 获取key

## 下载Java SDK
## 创建Java 项目
### 导入jar包
### 运行文档中的测试类
### JSON转Java对象
### 使用单例模式创建客户端