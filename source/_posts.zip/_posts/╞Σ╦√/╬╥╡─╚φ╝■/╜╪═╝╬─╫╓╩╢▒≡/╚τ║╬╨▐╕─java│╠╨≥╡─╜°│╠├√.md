---
title: 如何修改java程序的进程名
categories: 
  - 其他
  - 我的软件
  - 截图文字识别
abbrlink: 217f0f86
date: 2018-10-10 16:37:33
updated: 2022-04-04 15:13:22
---
# 如何修改java程序的进程名
我的实现过程：[把可执行jar打包成exe文件](/2018/10/10/MyApplications/截图文字识别/把可执行jar打包成exe文件/)
# 参考资料
相关论坛:
[https://bbs.csdn.net/topics/320018756](https://bbs.csdn.net/topics/320018756)
[https://bbs.csdn.net/topics/370063237](https://bbs.csdn.net/topics/370063237)
[https://bbs.csdn.net/topics/90400835](https://bbs.csdn.net/topics/90400835)

