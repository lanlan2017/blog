---
title: Github搜书
categories: 
  - 其他
  - 搜索
abbrlink: b6e31e08
date: 2019-12-25 09:26:01
updated: 2022-04-04 15:13:22
---
# 需要的工具
- 翻墙
- 谷歌搜索
- github

# 直接在github上搜索
直接[在github上搜索](https://github.com/search)

# 使用谷歌搜索github上的书籍
```
site:github.com 书名.pdf
```
